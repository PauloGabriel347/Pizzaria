package enums;

public enum TipoComida {

    PIZZA_SALGADA,
    PIZZA_DOCE,
    PIZZA_MISTA,
    LASANHA;

}
