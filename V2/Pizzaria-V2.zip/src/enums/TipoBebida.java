package enums;

public enum TipoBebida {

    COCA_COLA_2L,
    FRUKI_2L,
    CERVEJA,
    SUCO_LARANJA,
    SUCO_LIMAO,
    SUCO_UVA

}
