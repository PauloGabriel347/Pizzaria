package enums;

public enum TamanhoComida {

    BROTO,
    PEQUENO,
    MEDIO,
    GRANDE,
    FAMILIA

}
