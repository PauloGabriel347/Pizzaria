package enums;

public enum MetodoPagamento {

    EM_DINHEIRO,
    DEBITO,
    CREDITO,
    PIX;

}
