package enums;

public enum SituacaoPedido {

    EM_ANALISE,
    APROVADO,
    EM_PREPARO,
    EM_TRANSITO,
    FINALIZADO

}
